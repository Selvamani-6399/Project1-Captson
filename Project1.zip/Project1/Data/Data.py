"""
Data.py
"""

class webdata:

    def __init__(self):
        self.url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
        self.username = "Admin"
        self.password = "admin123"
        self.invalid_password = "Invalid_password"
        self.loginPageTitle = "OrangeHRM"
        self.dashboardURL = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index"
        self.firstname = "Selva"
        self.lastname = "mani"
        self.editlastnamev = "lastname"


